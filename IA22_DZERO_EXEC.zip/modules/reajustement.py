def learn(data):
    print(">> learn module activé")
    return data
