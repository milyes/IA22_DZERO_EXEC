def generate(data):
    print(">> generate module activé")
    return data
