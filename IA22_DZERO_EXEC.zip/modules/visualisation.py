def project(data):
    print(">> project module activé")
    return data
