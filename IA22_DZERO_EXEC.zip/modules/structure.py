def organize(data):
    print(">> organize module activé")
    return data
