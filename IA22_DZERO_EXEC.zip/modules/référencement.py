def index(data):
    print(">> index module activé")
    return data
