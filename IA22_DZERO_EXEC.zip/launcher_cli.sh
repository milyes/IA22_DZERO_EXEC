#!/bin/bash
echo "🔁 Lancement de IA22 DZERO CLI..."
python3 main.py
